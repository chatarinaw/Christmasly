
// MENAMPILKAN HALAMAN
function showPage(pageId) {
    const pages = [
        "homePage",
        "creatorPage",
        "recipientPage",
        "errorPage"
    ];

    pages.forEach(function(id) {
        document.getElementById(id).classList.add("hidden");
    });

    document.getElementById(pageId).classList.remove("hidden");

    if (
        pageId === "creatorPage" &&
        document.getElementById("questionContainer").children.length === 0
    ) {
        addQuestion();
    }
}


// MENAMBAHKAN PERTANYAAN QUIZ
function addQuestion() {
    const container = document.getElementById("questionContainer");

    if (container.children.length >= christmaslyData.maxQuestions) {
        alert("Maximum 10 questions!");
        return;
    }

    const number = container.children.length + 1;

    const card = document.createElement("div");
    card.className = "question-card";

    const title = document.createElement("h3");
    title.textContent = "Question " + number;
    card.appendChild(title);

    const questionLabel = document.createElement("label");
    questionLabel.textContent = "Your Question";
    card.appendChild(questionLabel);

    const questionInput = document.createElement("input");
    questionInput.type = "text";
    questionInput.className = "question-text";
    questionInput.placeholder = "Write your question...";
    questionInput.required = true;
    card.appendChild(questionInput);

    for (let i = 0; i < christmaslyData.maxOptions; i++) {
        const optionLabel = document.createElement("label");
        optionLabel.textContent = "Option " + (i + 1);
        card.appendChild(optionLabel);

        const optionInput = document.createElement("input");
        optionInput.type = "text";
        optionInput.className = "quiz-option";
        optionInput.placeholder = "Write option " + (i + 1);
        optionInput.required = true;
        card.appendChild(optionInput);
    }

    const correctLabel = document.createElement("label");
    correctLabel.textContent = "Correct Answer";
    card.appendChild(correctLabel);

    const correctSelect = document.createElement("select");
    correctSelect.className = "correct-answer";

    for (let i = 0; i < christmaslyData.maxOptions; i++) {
        const option = document.createElement("option");
        option.value = i;
        option.textContent = "Option " + (i + 1);
        correctSelect.appendChild(option);
    }

    card.appendChild(correctSelect);
    container.appendChild(card);
}


// MEMBUAT HADIAH
document.getElementById("giftForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const questionCards = document.querySelectorAll(".question-card");
    const questions = [];

    if (questionCards.length === 0) {
        alert("Please add at least one quiz question!");
        return;
    }

    for (let i = 0; i < questionCards.length; i++) {
        const card = questionCards[i];

        const question = card.querySelector(".question-text").value.trim();

        const options = Array.from(
            card.querySelectorAll(".quiz-option")
        ).map(function(input) {
            return input.value.trim();
        });

        const correctAnswer = Number(
            card.querySelector(".correct-answer").value
        );

        if (!question || options.some(function(option) {
            return option === "";
        })) {
            alert("Please complete all quiz questions and options!");
            return;
        }

        questions.push({
            question: question,
            options: options,
            correctAnswer: correctAnswer
        });
    }

    const gift = {
        creatorName: document.getElementById("creatorName").value.trim(),
        recipientName: document.getElementById("recipientName").value.trim(),
        greeting: document.getElementById("greeting").value.trim(),
        letter: document.getElementById("letter").value.trim(),
        questions: questions
    };

    // MEMBUAT LINK HADIAH UNTUK GITHUB PAGES
    const shareURL = new URL(window.location.href);

    shareURL.search = "";
    shareURL.hash = "";

    shareURL.searchParams.set("gift", JSON.stringify(gift));

    document.getElementById("shareLink").value = shareURL.href;

    document.getElementById("giftForm").classList.add("hidden");
    document.getElementById("shareSection").classList.remove("hidden");
});


// MENYALIN LINK
async function copyLink() {
    const linkInput = document.getElementById("shareLink");

    try {
        await navigator.clipboard.writeText(linkInput.value);
        alert("Gift link copied successfully!");
    } catch (error) {
        linkInput.select();
        linkInput.setSelectionRange(0, 99999);

        const copied = document.execCommand("copy");

        if (copied) {
            alert("Gift link copied successfully!");
        } else {
            alert("Please copy the link manually.");
        }
    }
}


// RESET CREATOR
function resetCreator() {
    document.getElementById("giftForm").reset();

    document.getElementById("questionContainer").innerHTML = "";

    document.getElementById("giftForm").classList.remove("hidden");
    document.getElementById("shareSection").classList.add("hidden");

    addQuestion();
}


// MEMBUKA SURAT
function openLetter() {
    const letterContent = document.getElementById("letterContent");

    letterContent.textContent = currentGift.letter;
    letterContent.classList.remove("hidden");
}


// DATA HADIAH YANG SEDANG DIBUKA
let currentGift = null;


// MENAMPILKAN HADIAH PENERIMA
function displayGift(gift) {
    if (
        !gift ||
        typeof gift !== "object" ||
        typeof gift.creatorName !== "string" ||
        typeof gift.recipientName !== "string" ||
        typeof gift.greeting !== "string" ||
        typeof gift.letter !== "string" ||
        !Array.isArray(gift.questions) ||
        gift.questions.length === 0 ||
        gift.questions.length > christmaslyData.maxQuestions
    ) {
        showPage("errorPage");
        return;
    }

    for (const question of gift.questions) {
        if (
            typeof question.question !== "string" ||
            !Array.isArray(question.options) ||
            question.options.length !== christmaslyData.maxOptions ||
            !question.options.every(function(option) {
                return typeof option === "string";
            }) ||
            !Number.isInteger(question.correctAnswer) ||
            question.correctAnswer < 0 ||
            question.correctAnswer >= christmaslyData.maxOptions
        ) {
            showPage("errorPage");
            return;
        }
    }

    currentGift = gift;

    document.getElementById("recipientGreeting").textContent = gift.greeting;

    document.getElementById("recipientIntro").textContent =
        "A special gift from " + gift.creatorName +
        " for " + gift.recipientName + ".";

    document.getElementById("letterContent").textContent = gift.letter;
    document.getElementById("letterContent").classList.add("hidden");

    document.getElementById("quizResult").classList.add("hidden");
    document.getElementById("finalMessage").classList.add("hidden");

    const quizContainer = document.getElementById("recipientQuiz");
    quizContainer.innerHTML = "";

    gift.questions.forEach(function(question, index) {
        const card = document.createElement("div");
        card.className = "question-card";

        const title = document.createElement("h3");
        title.textContent = (index + 1) + ". " + question.question;
        card.appendChild(title);

        question.options.forEach(function(option, optionIndex) {
            const label = document.createElement("label");
            label.className = "option";

            const radio = document.createElement("input");
            radio.type = "radio";
            radio.name = "question-" + index;
            radio.value = optionIndex;

            label.appendChild(radio);
            label.appendChild(document.createTextNode(option));

            card.appendChild(label);
        });

        quizContainer.appendChild(card);
    });

    showPage("recipientPage");
}


// MEMERIKSA JAWABAN QUIZ
function checkQuiz() {
    if (!currentGift) {
        return;
    }

    let score = 0;
    let unanswered = false;

    currentGift.questions.forEach(function(question, index) {
        const selected = document.querySelector(
            'input[name="question-' + index + '"]:checked'
        );

        if (!selected) {
            unanswered = true;
            return;
        }

        if (Number(selected.value) === question.correctAnswer) {
            score++;
        }
    });

    if (unanswered) {
        alert("Please answer all the questions first!");
        return;
    }

    const total = currentGift.questions.length;
    const result = document.getElementById("quizResult");

    result.textContent =
        "You got " + score + " out of " + total + " correct answers!";

    result.classList.remove("hidden");
    document.getElementById("finalMessage").classList.remove("hidden");
}


// MEMBACA LINK HADIAH
function loadGiftFromURL() {
    const params = new URLSearchParams(window.location.search);
    const giftData = params.get("gift");

    if (giftData === null) {
        showPage("homePage");
        return;
    }

    try {
        const gift = JSON.parse(giftData);
        displayGift(gift);
    } catch (error) {
        console.error("Gift data is invalid:", error);
        showPage("errorPage");
    }
}


// MENJALANKAN PROGRAM
document.addEventListener("DOMContentLoaded", function() {
    loadGiftFromURL();
});
