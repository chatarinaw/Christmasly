const christmaslyData = {
    appName: "Christmasly",
    tagline: "A Little Gift Made By You",
    maxQuestions: 10,
    maxOptions: 3
};
